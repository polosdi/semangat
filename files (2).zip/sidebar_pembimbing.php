<?php
// ============================================================
//  sidebar_pembimbing.php — Komponen Sidebar Pembimbing SIMPKL
//  Disesuaikan dengan peran pembimbing:
//  - Validasi jurnal harian siswa bimbingan
//  - Review laporan PKL
//  - Monitoring absensi & kehadiran
//  - Input nilai PKL
//  - Bimbingan & konsultasi
// ============================================================
if (!isset($active_page)) $active_page = '';

function si_p($href, $icon, $label, $key, $active, $badge = 0, $danger = false) {
    $ac = ($key === $active) ? 'active' : '';
    $dg = $danger ? 'danger' : '';
    echo "<a href='{$href}' class='sidebar-item {$ac} {$dg}' data-tooltip='{$label}'>
            <i class='{$icon}'></i><span>{$label}</span>";
    if ($badge > 0) echo "<span class='badge'>{$badge}</span>";
    echo "</a>";
}

// Hitung badge jurnal pending milik siswa bimbingan pembimbing ini
global $conn;
$badge_jurnal   = 0;
$badge_laporan  = 0;
if (isset($conn) && isset($_SESSION['user'])) {
    $pid = (int)$_SESSION['user']['id_user'];

    $rj = mysqli_query($conn,
        "SELECT COUNT(*) c FROM jurnal_harian j
         INNER JOIN pkl_pengajuan p ON j.siswa_id = p.ketua_id
         WHERE p.pembimbing_id = $pid AND j.status_validasi = 'pending'");
    if ($rj) $badge_jurnal = (int)mysqli_fetch_assoc($rj)['c'];

    $rl = mysqli_query($conn,
        "SELECT COUNT(*) c FROM laporan_pkl l
         INNER JOIN pkl_pengajuan p ON l.siswa_id = p.ketua_id
         WHERE p.pembimbing_id = $pid AND l.status_pembimbing = 'pending'");
    if ($rl) $badge_laporan = (int)mysqli_fetch_assoc($rl)['c'];
}
?>

<button class="sidebar-toggle" id="sidebarToggle" title="Toggle Sidebar">
  <i class="fas fa-chevron-left"></i>
</button>

<aside class="sidebar" id="sidebar">

  <div class="sidebar-section">
    <div class="sidebar-section-title">Utama</div>
    <?php si_p('dashboard_pembimbing.php', 'fas fa-th-large', 'Dashboard', 'dashboard', $active_page); ?>
  </div>

  <div class="sidebar-divider"></div>

  <div class="sidebar-section">
    <div class="sidebar-section-title">Siswa Bimbingan</div>
    <?php si_p('pembimbing-siswa.php',    'fas fa-user-graduate',  'Daftar Siswa',      'siswa',     $active_page); ?>
    <?php si_p('pembimbing-penempatan.php', 'fas fa-map-marker-alt', 'Penempatan PKL',    'penempatan',$active_page); ?>
  </div>

  <div class="sidebar-divider"></div>

  <div class="sidebar-section">
    <div class="sidebar-section-title">Monitoring PKL</div>
    <?php si_p('pembimbing-jurnal.php',   'fas fa-book-open',      'Jurnal Harian',     'jurnal',    $active_page, $badge_jurnal); ?>
    <?php si_p('pembimbing-absensi.php',  'fas fa-calendar-check', 'Absensi PKL',       'absensi',   $active_page); ?>
    <?php si_p('pembimbing-laporan.php',  'fas fa-file-alt',       'Laporan PKL',       'laporan',   $active_page, $badge_laporan); ?>
    <?php si_p('pembimbing-bimbingan.php','fas fa-comments',       'Bimbingan',         'bimbingan', $active_page); ?>
  </div>

  <div class="sidebar-divider"></div>

  <div class="sidebar-section">
    <div class="sidebar-section-title">Penilaian</div>
    <?php si_p('pembimbing-nilai.php',    'fas fa-star',           'Input Nilai',       'nilai',     $active_page); ?>
    <?php si_p('pembimbing-kompetensi.php','fas fa-tasks',         'Kompetensi',        'kompetensi',$active_page); ?>
  </div>

  <div class="sidebar-divider"></div>

  <div class="sidebar-section">
    <?php si_p('../logout.php', 'fas fa-sign-out-alt', 'Logout', 'logout', $active_page, 0, true); ?>
  </div>

</aside>

<div class="sidebar-overlay" id="sidebarOverlay"></div>
